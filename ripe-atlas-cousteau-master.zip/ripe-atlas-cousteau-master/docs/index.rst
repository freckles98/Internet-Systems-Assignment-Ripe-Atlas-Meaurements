.. RIPE Atlas Cousteau documentation master file, created by
   sphinx-quickstart on Wed Jan 13 16:02:54 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

RIPE Atlas Cousteau
===================
Welcome to the official python wrapper around RIPE Atlas API.
This package can used by anyone to communicate with the RIPE Atlas API using python. You will need to have an API key in most of the cases in order your requests to be successful.

This package is maintained by RIPE Atlas developers.


Contents:
=========

.. toctree::
   :maxdepth: 2

   installation
   use
   contributing
   changelog

